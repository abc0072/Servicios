module org.proyect2.hallowen {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens org.proyect2.hallowen to javafx.fxml;
    exports org.proyect2.hallowen;
}