package org.proyect2.hallowen;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.io.IOException;

public class Ventana1Controller {
    @FXML
    private Pane panel;
    @FXML
    private TextField nombre;
    @FXML
    private TextField apellido;
    @FXML
    private ComboBox curso;


    @FXML
    private void cambiarVentana(ActionEvent event) throws IOException {
        String nombre = this.nombre.getText();
        String apellido = this.apellido.getText();
        String curso = (String) this.curso.getValue();

        if(nombre.isEmpty()) {
            mostrarAlerta("Error de Usuario", "El nombre de usuario debe estar relleno");
        } else if (apellido.isEmpty()) {
            mostrarAlerta("Error de Apellido", "El apellido debe estar relleno");
        } else if (curso == null) {
            mostrarAlerta("Error de Curso", "El curso debe estar relleno");
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Ventana2.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Ventana2Controller controller = loader.getController();
            controller.cogerDatos(nombre, apellido, curso);

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }

    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.show();
    }

}
