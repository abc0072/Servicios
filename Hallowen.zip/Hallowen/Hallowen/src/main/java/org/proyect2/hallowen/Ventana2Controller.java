package org.proyect2.hallowen;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.util.Random;

public class Ventana2Controller {

    @FXML
    private ImageView foto;
    @FXML
    private ImageView flecha;
    @FXML
    private Button boton2;
    @FXML
    private Label contenedor;



    private final Random random = new Random();

    @FXML
    public void girarRuleta() {
        boton2.setDisable(true);
        contenedor.setText("");

        // Giro aleatorio entre 3 y 6 vueltas completas + ángulo extra aleatorio
        double vueltas = 360 * (3 + random.nextInt(4)); // 3, 4, 5 o 6 vueltas
        double anguloExtra = random.nextDouble() * 360; // rotación adicional aleatoria
        double rotacionFinal = vueltas + anguloExtra;

        RotateTransition rotacion = new RotateTransition(Duration.seconds(3), foto);
        rotacion.setByAngle(rotacionFinal);
        rotacion.setInterpolator(Interpolator.EASE_OUT);

        rotacion.setOnFinished(e -> {
            boton2.setDisable(false);

            // Normalizar ángulo final a 0-360
            double anguloFinalNormalizado = foto.getRotate() % 360;
            if (anguloFinalNormalizado < 0) {
                anguloFinalNormalizado += 360;
            }

            // Decidir Truco o Trato
            if (anguloFinalNormalizado >= 92 && anguloFinalNormalizado <= 273) {
                mostrarAlerta("Trato", "Trato: Recibes un dulce");
            } else {
                mostrarAlerta("Truco", "Truco: Prepárate para un susto");

            }
        });

        rotacion.play();
    }


    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.show();
    }

   public void cogerDatos(String nombre, String apellido, String curso) {
        contenedor.setText(nombre + " " + apellido + " " + curso);
   }
}
